# Output data

Output data from Jupyter exercises (accessible from Jupyter
in `../data/output`).
